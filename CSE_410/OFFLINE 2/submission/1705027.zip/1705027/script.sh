echo "Compiling..."
g++ -o 1705027 1705027.cpp
echo "Running..."
./1705027 "input/scene.txt" "input/config.txt"
echo "done"