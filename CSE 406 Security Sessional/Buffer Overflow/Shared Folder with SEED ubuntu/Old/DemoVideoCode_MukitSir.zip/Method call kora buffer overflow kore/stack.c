#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* Changing this size will change the layout of the stack.
 * Instructors can change this value each year, so students
 * won't be able to use the solutions from the past.
 */
#ifndef BUF_SIZE
#define BUF_SIZE 100
#endif



int bof(char *str)
{
    char buffer[24];

    // The following statement has a buffer overflow problem 
    strcpy(buffer, str);
    printf("returning from bof\n");       

    return 1;
}

int foo(){
	printf("Sensitive information leaked\n");
	return 1;
}

int main(int argc, char **argv)
{
    char str[300];
    FILE *badfile;

    badfile = fopen("badfile", "r");
    printf("Inside main\n"); 
    if (!badfile) {
       perror("Opening badfile"); exit(1);
    }

    fread(str, sizeof(char), 300, badfile);
    bof(str);
    printf("==== Returned Properly ====\n");
    return 1;
}


